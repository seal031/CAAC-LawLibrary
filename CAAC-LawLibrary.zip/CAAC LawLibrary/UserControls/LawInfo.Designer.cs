﻿namespace CAAC_LawLibrary.UserControls
{
    partial class LawInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_buhao = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_linghao = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_banwendanwei = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_guanlijigou = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_leixing = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_yewufenlei = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_guanjianzi = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_xiudingling = new System.Windows.Forms.Label();
            this.rtb_zhaiyao = new System.Windows.Forms.RichTextBox();
            this.rtb_yilai = new System.Windows.Forms.RichTextBox();
            this.rtb_zefa = new System.Windows.Forms.RichTextBox();
            this.ccb_banben = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(5, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "规章名：";
            // 
            // lbl_name
            // 
            this.lbl_name.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_name.Location = new System.Drawing.Point(85, 10);
            this.lbl_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(173, 16);
            this.lbl_name.TabIndex = 1;
            // 
            // lbl_buhao
            // 
            this.lbl_buhao.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_buhao.Location = new System.Drawing.Point(85, 44);
            this.lbl_buhao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_buhao.Name = "lbl_buhao";
            this.lbl_buhao.Size = new System.Drawing.Size(173, 16);
            this.lbl_buhao.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(5, 44);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "部号：";
            // 
            // lbl_linghao
            // 
            this.lbl_linghao.AutoSize = true;
            this.lbl_linghao.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_linghao.Location = new System.Drawing.Point(55, 78);
            this.lbl_linghao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_linghao.Name = "lbl_linghao";
            this.lbl_linghao.Size = new System.Drawing.Size(0, 20);
            this.lbl_linghao.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(5, 77);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "令号：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(5, 114);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "版本：";
            // 
            // lbl_banwendanwei
            // 
            this.lbl_banwendanwei.AutoSize = true;
            this.lbl_banwendanwei.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_banwendanwei.Location = new System.Drawing.Point(85, 148);
            this.lbl_banwendanwei.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_banwendanwei.Name = "lbl_banwendanwei";
            this.lbl_banwendanwei.Size = new System.Drawing.Size(0, 20);
            this.lbl_banwendanwei.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(5, 148);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "办文单位：";
            // 
            // lbl_guanlijigou
            // 
            this.lbl_guanlijigou.AutoSize = true;
            this.lbl_guanlijigou.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_guanlijigou.Location = new System.Drawing.Point(85, 186);
            this.lbl_guanlijigou.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_guanlijigou.Name = "lbl_guanlijigou";
            this.lbl_guanlijigou.Size = new System.Drawing.Size(0, 20);
            this.lbl_guanlijigou.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(5, 186);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "管理机构：";
            // 
            // lbl_leixing
            // 
            this.lbl_leixing.AutoSize = true;
            this.lbl_leixing.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_leixing.Location = new System.Drawing.Point(87, 221);
            this.lbl_leixing.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_leixing.Name = "lbl_leixing";
            this.lbl_leixing.Size = new System.Drawing.Size(0, 20);
            this.lbl_leixing.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(7, 221);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 20);
            this.label14.TabIndex = 12;
            this.label14.Text = "类型：";
            // 
            // lbl_yewufenlei
            // 
            this.lbl_yewufenlei.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_yewufenlei.Location = new System.Drawing.Point(87, 256);
            this.lbl_yewufenlei.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_yewufenlei.Name = "lbl_yewufenlei";
            this.lbl_yewufenlei.Size = new System.Drawing.Size(173, 16);
            this.lbl_yewufenlei.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(7, 256);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 20);
            this.label16.TabIndex = 14;
            this.label16.Text = "业务分类：";
            // 
            // lbl_guanjianzi
            // 
            this.lbl_guanjianzi.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_guanjianzi.Location = new System.Drawing.Point(85, 292);
            this.lbl_guanjianzi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_guanjianzi.Name = "lbl_guanjianzi";
            this.lbl_guanjianzi.Size = new System.Drawing.Size(173, 16);
            this.lbl_guanjianzi.TabIndex = 17;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(5, 292);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 20);
            this.label18.TabIndex = 16;
            this.label18.Text = "关键字：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(7, 334);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 20);
            this.label19.TabIndex = 18;
            this.label19.Text = "修订令：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(7, 398);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 20);
            this.label20.TabIndex = 19;
            this.label20.Text = "责罚：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(7, 516);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(54, 20);
            this.label21.TabIndex = 20;
            this.label21.Text = "依赖：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(7, 638);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 20);
            this.label22.TabIndex = 21;
            this.label22.Text = "摘要：";
            // 
            // lbl_xiudingling
            // 
            this.lbl_xiudingling.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_xiudingling.Location = new System.Drawing.Point(7, 364);
            this.lbl_xiudingling.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_xiudingling.Name = "lbl_xiudingling";
            this.lbl_xiudingling.Size = new System.Drawing.Size(252, 16);
            this.lbl_xiudingling.TabIndex = 22;
            // 
            // rtb_zhaiyao
            // 
            this.rtb_zhaiyao.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rtb_zhaiyao.Location = new System.Drawing.Point(8, 657);
            this.rtb_zhaiyao.Margin = new System.Windows.Forms.Padding(4);
            this.rtb_zhaiyao.Name = "rtb_zhaiyao";
            this.rtb_zhaiyao.ReadOnly = true;
            this.rtb_zhaiyao.Size = new System.Drawing.Size(232, 131);
            this.rtb_zhaiyao.TabIndex = 25;
            this.rtb_zhaiyao.Text = "";
            // 
            // rtb_yilai
            // 
            this.rtb_yilai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rtb_yilai.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rtb_yilai.Location = new System.Drawing.Point(11, 535);
            this.rtb_yilai.Margin = new System.Windows.Forms.Padding(4);
            this.rtb_yilai.Name = "rtb_yilai";
            this.rtb_yilai.ReadOnly = true;
            this.rtb_yilai.Size = new System.Drawing.Size(232, 75);
            this.rtb_yilai.TabIndex = 26;
            this.rtb_yilai.Text = "";
            this.rtb_yilai.Click += new System.EventHandler(this.rtb_yilai_Click);
            // 
            // rtb_zefa
            // 
            this.rtb_zefa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rtb_zefa.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rtb_zefa.Location = new System.Drawing.Point(11, 420);
            this.rtb_zefa.Margin = new System.Windows.Forms.Padding(4);
            this.rtb_zefa.Name = "rtb_zefa";
            this.rtb_zefa.ReadOnly = true;
            this.rtb_zefa.Size = new System.Drawing.Size(232, 64);
            this.rtb_zefa.TabIndex = 27;
            this.rtb_zefa.Text = "";
            this.rtb_zefa.Click += new System.EventHandler(this.rtb_zefa_Click);
            // 
            // ccb_banben
            // 
            this.ccb_banben.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ccb_banben.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ccb_banben.FormattingEnabled = true;
            this.ccb_banben.Location = new System.Drawing.Point(69, 110);
            this.ccb_banben.Margin = new System.Windows.Forms.Padding(4);
            this.ccb_banben.Name = "ccb_banben";
            this.ccb_banben.Size = new System.Drawing.Size(61, 28);
            this.ccb_banben.TabIndex = 28;
            this.ccb_banben.SelectedIndexChanged += new System.EventHandler(this.ccb_banben_SelectedIndexChanged);
            // 
            // LawInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.ccb_banben);
            this.Controls.Add(this.rtb_zefa);
            this.Controls.Add(this.rtb_yilai);
            this.Controls.Add(this.rtb_zhaiyao);
            this.Controls.Add(this.lbl_xiudingling);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lbl_guanjianzi);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lbl_yewufenlei);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lbl_leixing);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lbl_guanlijigou);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbl_banwendanwei);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl_linghao);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_buhao);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "LawInfo";
            this.Size = new System.Drawing.Size(264, 807);
            this.Load += new System.EventHandler(this.LawInfo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_buhao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_linghao;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_banwendanwei;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_guanlijigou;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_leixing;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_yewufenlei;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_guanjianzi;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_xiudingling;
        private System.Windows.Forms.RichTextBox rtb_zhaiyao;
        private System.Windows.Forms.RichTextBox rtb_yilai;
        private System.Windows.Forms.RichTextBox rtb_zefa;
        public System.Windows.Forms.ComboBox ccb_banben;
    }
}
